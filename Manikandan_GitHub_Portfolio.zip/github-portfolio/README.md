# V. Manikandan — Academic Portfolio

**Mr. V. Manikandan, M. Pharm (Pharmaceutics)**  
Assistant Professor | Pharmaceutics · Novel Drug Delivery Systems · Pharmaceutical Nanotechnology · QbD

---

## Live Portfolio

> After enabling GitHub Pages, your site will be available at:  
> `https://<your-username>.github.io/<repo-name>/`

---

## About

This repository hosts the personal academic portfolio of **Mr. V. Manikandan**, Assistant Professor in the Department of Pharmaceutics.

**Focus areas:**
- Novel Drug Delivery Systems (NDDS)
- Pharmaceutical Nanotechnology
- Vesicular systems (Ufasomes, Spanlastics)
- Quality by Design (QbD) & Design of Experiments (DoE)
- Topical and Transdermal Drug Delivery

---

## Contents

| File | Description |
|------|-------------|
| `index.html` | Single-page academic portfolio website |
| `README.md` | This file |

---

## How to Deploy on GitHub Pages (Free)

### 1. Create a new repository
1. Go to [github.com/new](https://github.com/new)
2. Repository name example: `portfolio` or `academic-portfolio`
3. Set visibility to **Public**
4. Do **not** initialize with README (this repo already has one)
5. Click **Create repository**

### 2. Upload / push these files
**Option A — Upload via browser**
1. On the new repo page, click **uploading an existing file**
2. Drag `index.html` and `README.md` into the area
3. Commit

**Option B — Using Git (recommended)**
```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
# copy index.html and README.md into this folder
git add .
git commit -m "Add academic portfolio website"
git branch -M main
git push -u origin main
```

### 3. Enable GitHub Pages
1. Open the repository → **Settings** → **Pages**
2. Under **Source**, select **Deploy from a branch**
3. Branch: `main` · Folder: `/ (root)`
4. Click **Save**
5. Wait 1–2 minutes, then open:  
   `https://<your-username>.github.io/<repo-name>/`

---

## Contact

| | |
|---|---|
| **Email** | [vmkandan01@gmail.com](mailto:vmkandan01@gmail.com) |
| **Mobile** | 8610515815 |
| **LinkedIn** | [linkedin.com/in/manikandan-v-794351221](https://www.linkedin.com/in/manikandan-v-794351221) |
| **ORCID** | [0009-0005-3938-4202](https://orcid.org/0009-0005-3938-4202) |
| **Google Scholar** | S2-norgAAAAJ |
| **Location** | Vriddhachalam, Tamil Nadu, India |

---

## License

This portfolio content is personal academic information of Mr. V. Manikandan.  
You may fork the *structure* for your own portfolio; please do not reuse personal details.
